```markdown
# TP DevOps Avancé - ENSIIE

---

## Partie 1 : Résilience avec Topology Spread Constraints

### Commandes utilisées et contexte

- `kubectl get nodes`  
  Pour vérifier la présence de plusieurs nœuds dans Minikube.
- Modification du fichier `deployment.yaml` pour ajouter le bloc suivant afin d'assurer la répartition équilibrée des pods :
  ```
  topologySpreadConstraints:
    - maxSkew: 1
      topologyKey: kubernetes.io/hostname
      whenUnsatisfiable: DoNotSchedule
      labelSelector:
        matchLabels:
          app: guestbook
  ```
- `kubectl apply -f deployment.yaml`  
  Pour appliquer la configuration modifiée.
- `minikube node delete <nom_du_noeud>`  
  Simulation d'une panne d'un nœud.
- `kubectl get pods -o wide`  
  Vérification de la redistribution des pods sur les autres nœuds.
- `minikube node add <nom_du_noeud>`  
  Remise en fonction du nœud.

### Problèmes rencontrés

- Aucun problème bloquant, mais nécessité de bien comprendre les paramètres `maxSkew` et `topologyKey` sous peine d'une mauvaise répartition.

### Solutions apportées

- Itération de tests et vérification régulière de la bonne répartition des pods.

### Apprentissage

- Les `topologySpreadConstraints` sont essentielles pour garantir la haute disponibilité en évitant la concentration des pods sur un seul nœud.

---

## Partie 2 : Installation et configuration de kube-prometheus-stack

### Commandes utilisées et contexte

- `helm repo add prometheus-community https://prometheus-community.github.io/helm-charts`  
  Ajout du repository Helm.
- `helm repo update`  
  Mise à jour des charts.
- `helm install prometheus prometheus-community/kube-prometheus-stack -n monitoring --create-namespace`  
  Installation de la stack monitoring.
- `kubectl get pods -n monitoring`  
  Vérification du déploiement des pods.
- `kubectl port-forward svc/kube-prometheus-stack-grafana -n monitoring 3000:80`  
  Pour accéder au dashboard Grafana localement.
- `kubectl edit configmap custom-prometheus-config -n monitoring`  
  Ajout de la configuration pour scrapper l'application guestbook.
- `kubectl rollout restart deployment prometheus-server -n monitoring`  
  Redémarrage de Prometheus pour prendre en compte la nouvelle configuration.

### Problèmes rencontrés

- Accès à Grafana impossible sans port-forward.
- Les métriques de guestbook n'étaient pas scrappées initialement.

### Solutions apportées

- Mise en place d’un port-forward stable.
- Modification précise de la ConfigMap.
- Redémarrage de Prometheus.

### Apprentissage

- Helm facilite les déploiements complexes, mais la personnalisation reste obligatoire.
- L’édition de ConfigMap permet d’ajouter des cibles de scraping, indispensable pour le monitoring.

---

## Partie 3 : Tests de charge K6 via Ingress et LoadBalancer

### Commandes utilisées et contexte

- `minikube addons enable ingress`  
  Activation de l’Ingress Controller.
- Application du manifeste Ingress (fichier YAML) exposant guestbook.
- `minikube tunnel`  
  Pour exposer le service LoadBalancer localement.
- Modification du script K6 pour viser l’URL via Ingress.
- Lancement du test : `k6 run test.js`.
- Observation des pod et des métriques via Grafana.
- `kubectl get hpa -n monitoring` pour surveiller l'autoscaling.

### Problèmes rencontrés

- Erreurs lors du test ciblant un pod précis.
- Difficultés d'exposition réseau.

### Solutions apportées

- Passage par Ingress et tunnel pour load-balancer.
- Adaptation du script K6.

### Apprentissage

- L’Ingress est indispensable pour équilibrer la charge.
- Les tests de charge doivent viser la bonne URL pour simuler un vrai trafic.

---

## Partie 4 : Dashboard Grafana personnalisé pour les métriques /info

### Commandes utilisées et contexte

- Exploration du endpoint `/info` pour comprendre les métriques spécifiques.
- Création manuelle d’un dashboard Grafana.
- Ajout de panels avec requêtes PromQL adaptées.
- Configuration d’alertes simples sur certaines métriques.

### Problèmes rencontrés

- Difficulté à maitriser la syntaxe PromQL.

### Solutions apportées

- Lecture attentive de la documentation et essais successifs.

### Apprentissage

- PromQL est un langage puissant mais complexe.
- La visualisation métier augmente la pertinence du monitoring.

---

## Partie 5 : Chaos Mesh - Lancement d'une expérience pod-kill

### Commandes utilisées et contexte

- `helm repo add chaos-mesh https://charts.chaos-mesh.org`  
  Ajout du repo Helm Chaos Mesh.
- `helm install chaos-mesh chaos-mesh/chaos-mesh -n chaos-testing --set dashboard.create=true`  
  Installation de Chaos Mesh.
- Création manuelle du serviceaccount et clusterrolebinding via YAML (fichier chaos-dashboard-sa.yaml) :
  ```
  apiVersion: v1
  kind: ServiceAccount
  metadata:
    name: chaos-dashboard-sa
    namespace: chaos-testing
  ---
  apiVersion: rbac.authorization.k8s.io/v1
  kind: ClusterRoleBinding
  metadata:
    name: chaos-dashboard-sa-binding
  subjects:
  - kind: ServiceAccount
    name: chaos-dashboard-sa
    namespace: chaos-testing
  roleRef:
    kind: ClusterRole
    name: cluster-admin
    apiGroup: rbac.authorization.k8s.io
  ```
- Application via : `kubectl apply -f chaos-dashboard-sa.yaml`
- Création token RBAC : `kubectl -n chaos-testing create token chaos-dashboard-sa`
- Port-forward du dashboard : `kubectl port-forward -n chaos-testing svc/chaos-dashboard 9999:2333`
- Connexion au dashboard avec le token généré.
- Création puis application de l’expérience pod-kill (fichier pod-kill-example.yaml corrigé sans `scheduler`).
- Observation en temps réel des pods tués et recréés :  
  `kubectl get pods -n monitoring -l app=guestbook --watch`
- Monitoring simultané dans Grafana.

### Problèmes rencontrés

- Dashboard Chaos Mesh bloqué par absence de token.
- Token serviceaccount non généré automatiquement.
- Erreur de syntaxe YAML avec la clé `scheduler` non reconnue.

### Solutions apportées

- Création manuelle du serviceaccount et clusterrolebinding.
- Génération manuelle du token via `kubectl create token`.
- Suppression de la clé `scheduler` dans le manifeste Chaos Mesh.

### Apprentissage

- Complexité de la gestion RBAC dans Chaos Mesh.
- Besoin d’un token pour sécuriser l’accès au dashboard.
- Intégration efficace du chaos engineering dans un environnement supervisé.

---

# Conclusion

Ce TP a permis d’aborder un ensemble complet de compétences DevOps en contexte Kubernetes : résilience, monitoring, tests de charge, visualisation métier et chaos engineering.
---

Fin du README.

