import http from 'k6/http';
import { sleep } from 'k6';

export default function () {
    http.get('http://guestbook.fbi.com/');
    sleep(1); // attend 1 seconde entre chaque requête
}
